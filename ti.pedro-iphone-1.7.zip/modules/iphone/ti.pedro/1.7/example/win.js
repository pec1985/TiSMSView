
function TalkToServer(a){
	var xhr = Titanium.Network.createHTTPClient();
	xhr.open('POST','http://pec1985.com/bot/api.php#'+new Date().getTime());
	
	xhr.onerror = function(e){
		alert(e.error);
	};
	
	xhr.setTimeout(200000);
	
	xhr.onload = function(e){
		Ti.App.Properties.setString('cookie', xhr.getResponseHeader('Set-Cookie'));
		a.callBack(this.responseText);
	};
	
	xhr.setRequestHeader("contentType", "form-data");
	xhr.setRequestHeader('Set-Cookie', Ti.App.Properties.getString('cookie',null));
	xhr.send({
			 chat:a.text,
			 action:"checkresponse"
	});
}

var win = Ti.UI.currentWindow;
Titanium.Pedro = require('ti.pedro');

var tf = Ti.Pedro.createSMSView({
	backgroundColor: '#b7d4fa',
	sendColor: 'Purple',
	recieveColor: 'Green',
	editable: true,
	animated:false
});

win.add(tf);

tf.addEventListener('buttonClicked', function(e) {
	if (tf.value == 'exit' || tf.value == 'Exit') {
		win.close();
	} else {
//		tf.sendMessage(e.value);
//					TalkToServer({
//						 text:e.value,
//						 callBack:function(a){
//							tf.recieveMessage(a);
//						 }
//					});
					tf.recieveMessage(tf.value);
	}
});

win.addEventListener('open', function() {
	tf.recieveMessage('Type "exit" to exit');
});
